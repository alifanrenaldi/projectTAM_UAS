package com.example.project531.Interface;

import com.example.project531.Domain.Login;
import com.example.project531.Domain.Register;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface KoneksiModel {

    @POST("login.php")
    @FormUrlEncoded
    Call< Login > login(@Field("username") String username,
                        @Field("password") String password);
    @POST("create.php")
    @FormUrlEncoded
    Call< Register > registrasi(@Field("username") String username,
                                @Field("password") String password,
                                @Field("email") String email,
                                @Field("phone") String phone);
}
