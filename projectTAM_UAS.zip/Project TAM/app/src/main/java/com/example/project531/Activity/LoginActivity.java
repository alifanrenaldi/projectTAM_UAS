package com.example.project531.Activity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.project531.Domain.Connection;
import com.example.project531.Domain.Login;
import com.example.project531.Helper.TokenAccess;
import com.example.project531.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LoginActivity extends AppCompatActivity {
    private EditText user, pass;
    private Button btnLogin, btnDaftar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();
        btnLogin.setOnClickListener(view -> {
            getLogin();
        });
        btnDaftar.setOnClickListener(view -> {
            Intent daftar = new Intent(this, RegisterActivity.class);
            startActivity(daftar);
        });

    }

    private void getLogin() {
        if (user.getText().toString().trim().isEmpty()){
            user.setError("Username Harus diisi");
        }else if (pass.getText().toString().trim().isEmpty()){
            user.setError("Password harus diisi");
        }else{
            Call< Login > loginCall = Connection.send().login(user.getText().toString().trim(), pass.getText().toString().trim());
            loginCall.enqueue(new Callback< Login >() {
                @Override
                public void onResponse(Call< Login > call, Response< Login > response) {
                    if (response.isSuccessful()){
                        if (response.body().getStatus().equals("success")){
                            TokenAccess token = new TokenAccess(LoginActivity.this);
                            token.saveToken(response.body().getUsername(),
                                    Integer.parseInt(response.body().getId()),
                                    response.body().getEmail(),
                                    response.body().getPhone());
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }else if (response.body().getStatus().equals("password")){
                            Toast.makeText(LoginActivity.this, "Username & Password tidak cocok", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(LoginActivity.this, "Username tidak ditemukan", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(LoginActivity.this, "Eror Koneksi", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call< Login > call, Throwable t) {
                    Toast.makeText(LoginActivity.this, "Eror internal", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public void initView(){
        user = findViewById(R.id.etUsername);
        pass = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnDaftar = findViewById(R.id.btn_daftar);
    }
}