package com.example.project531.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.project531.Domain.Connection;
import com.example.project531.Domain.Register;
import com.example.project531.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {
    private EditText username, password, email, phone;
    private Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        initView();
        register.setOnClickListener(view -> {
            if (username.getText().toString().trim().isEmpty()) {
                username.setError("Username harus diisi");
            } else if (password.getText().toString().trim().isEmpty()) {
                password.setError("Password harus diisi");
            } else if (email.getText().toString().trim().isEmpty()) {
                email.setError("Email harus diisi");
            } else if (phone.getText().toString().trim().isEmpty()) {
                phone.setError("No.Handphone harus di isi");
            } else if (username.getText().toString().length() < 4){
                username.setError("Username harus lebih dari 4 kata");
            } else {
                registrasi();
            }
        });
    }

    private void registrasi() {
        Call< Register > registerCall = Connection.send().registrasi(
                username.getText().toString().trim(),
                password.getText().toString().trim(),
                email.getText().toString().trim(),
                phone.getText().toString().trim()
        );
        registerCall.enqueue(new Callback< Register >() {
            @Override
            public void onResponse(Call< Register > call, Response< Register > response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        Toast.makeText(RegisterActivity.this, "Pendaftaran Berhasil", Toast.LENGTH_SHORT).show();
                        username.getText().clear();
                        password.getText().clear();
                        email.getText().clear();
                        phone.getText().clear();
                        Intent login = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(login);
                    } else {
                        Toast.makeText(RegisterActivity.this, "Pendaftaran Gagal", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(RegisterActivity.this, "Pendaftaran Gagal", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call< Register > call, Throwable t) {
                Toast.makeText(RegisterActivity.this, "Eror internal", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initView() {
        username = findViewById(R.id.username_register);
        password = findViewById(R.id.password_register);
        email = findViewById(R.id.email_register);
        phone = findViewById(R.id.phone_register);
        register = findViewById(R.id.button_register);
    }

}