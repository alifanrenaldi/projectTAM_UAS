package com.example.project531.Helper;

import android.content.Context;
import android.content.SharedPreferences;

public class TokenAccess {
    private final SharedPreferences sharedPreferences;
    private final SharedPreferences.Editor editor;
    private final String USERKEY = "USERNAME";
    private final String IDKEY = "ID";
    private final String EMAILKEY = "EMAIL";
    private final String HPKEY = "PHONE";

    public TokenAccess(Context context) {
        this.sharedPreferences = context.getSharedPreferences("TOKEN", Context.MODE_PRIVATE);
        this.editor = sharedPreferences.edit();
    }

    public void saveToken(String username, int id, String email, String phone) {
        editor.putString(USERKEY, username).commit();
        editor.putInt(IDKEY, id).commit();
        editor.putString(EMAILKEY, email).commit();
        editor.putString(HPKEY, phone).commit();
    }

    public String getSessionUser() {
        return sharedPreferences.getString(USERKEY, "null");
    }

    public int getSessionID() {
        return sharedPreferences.getInt(IDKEY, 0);
    }

    public String getSessionEmail() {
        return sharedPreferences.getString(EMAILKEY, "null");
    }

    public String getSessionPhone() {
        return sharedPreferences.getString(HPKEY, "null");
    }

    public void removeToken() {
        editor.putString(USERKEY, "null").commit();
        editor.putInt(IDKEY, 0).commit();
    }
}
