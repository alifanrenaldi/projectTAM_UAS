package com.example.project531.Interface;

public interface ChangeNumberItemsListener {
    void changed();
}
