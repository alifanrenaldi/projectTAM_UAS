package com.example.project531.Activity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.project531.Helper.TokenAccess;
import com.example.project531.R;

public class ProfilActivity extends AppCompatActivity {
    private Button btnLogOut;
    private TextView username, email, phone, fb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);
        initview();
        setProfile();
        btnLogOut.setOnClickListener(view -> {
            TokenAccess tokenAccess = new TokenAccess(this);
            tokenAccess.removeToken();
            Intent logOut = new Intent(this, LoginActivity.class);
            logOut.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(logOut);
        });
    }

    private void setProfile() {
        TokenAccess profile = new TokenAccess(this);
        username.setText(profile.getSessionUser());
        email.setText(profile.getSessionEmail());
        phone.setText(profile.getSessionPhone());
        fb.setText(profile.getSessionUser());
    }

    private void initview() {
        btnLogOut = findViewById(R.id.btnLogOut);
        username = findViewById(R.id.tv_name);
        email = findViewById(R.id.email_value);
        phone = findViewById(R.id.value_phone);
        fb = findViewById(R.id.facebook_value);
    }
}